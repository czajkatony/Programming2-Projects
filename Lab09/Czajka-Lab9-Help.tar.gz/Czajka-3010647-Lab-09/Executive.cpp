#include "Executive.h"

Executive::Executive(std::string FileName){
	Pokedex=new BinarySearchTree<Pokemon, int>();
	std::fstream inFile;
	inFile.open(FileName);
	while(inFile.is_open()){
		std::string tempUS;
		std::string tempJP;
		int tempID;
		while(inFile >> tempUS >> tempID >> tempJP){
			Pokemon addition(tempID, tempUS, tempJP);
			Pokedex->add(addition);
		}
	}
	inFile.close();
}
