template <typename ItemType, typename KeyType>
BinarySearchTree<ItemType, KeyType>::BinarySearchTree(){
  m_root=nullptr;
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::addHelper(Bnode<ItemType>* newNode, Bnode<ItemType>* compare){
  if(compare==nullptr){
    compare=newNode;
  }
  else if(newNode->getEntry()>compare->getEntry()){
    addHelper(newNode,compare->getRightPtr());
  }
  else if(newNode->getEntry()<compare->getEntry()){
    addHelper(newNode,compare->getLeftPtr());
  }
  else{
    throw(std::runtime_error("Duplicates may not be added to Binary Search Tree."));
  }
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::add(ItemType entry){
	Bnode<ItemType>* temp=new Bnode<ItemType>(entry);
  try{

	  if(m_root==nullptr){
		  m_root=temp;
	  }
	  else{
		addHelper(temp,m_root);
	  }
  }
  catch(std::runtime_error& e){
    std::cout<<"ERROR: "<<e.what()<<'\n';
    delete temp;
  }
}
//============================VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV============================

template <typename ItemType, typename KeyType>
ItemType BinarySearchTree<ItemType, KeyType>::search(KeyType key)const{
  Bnode<ItemType>* compare=m_root;
  while(compare!=nullptr){
	  if(compare->getEntry()==key){
		  return(compare->getEntry());
	  }
	  else if(compare->getEntry()<key){
		  compare=compare->getRightPtr();
	  }
	  else if(compare->getEntry()>key){
		  compare=compare->getLeftPtr();
	  }
  }
  throw(std::runtime_error("Pokemon with this ID not found."));
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::clear(){}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::remove(KeyType key){
	/**
	try{
		m_root=removeHelper(key, m_root);
	}
	catch(std::runtime_error& e){
		std::cout<<"ERROR: "<<e.what()<<'\n';
	}
	**/
}

template <typename ItemType, typename KeyType>
Bnode<ItemType>* BinarySearchTree<ItemType, KeyType>::removeHelper(KeyType key, Bnode<ItemType>* temp){
	/**
		if(temp==key){ //base case stuff
			//root is removed
			if(m_root==temp){
				delete temp;
				m_root=nullptr;
				return(m_root);
			}
			//no child not root
			else if(temp->getRightPtr()==nullptr&&temp->getLeftPtr()==nullptr){
				delete temp;
				return(m_root);
			}
			//two children
			else if(temp->getRightPtr()!=nullptr&&temp->getLeftPtr()!=nullptr){}
			//one child
			else if(temp->getRightPtr()==nullptr||temp->getLeftPtr()==nullptr){
				
			}

		}
		else if(temp>key){
			removeHelper(key, temp->getLeftPtr());
		}
		else if(temp<key){
			removeHelper(key, temp->getRightPtr());
		}	
		**/
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrder(void visit(ItemType))const{
	visitPreOrderHelper(m_root, visit);
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrder(void visit(ItemType))const{
	visitInOrderHelper(m_root, visit);
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrder(void visit(ItemType))const{
	visitPostOrderHelper(m_root, visit);
}


template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPreOrderHelper(Bnode<ItemType>* temp, void visit(ItemType))const{
	visit;
	visitPreOrderHelper(temp->getLeftPtr(),visit);
	visitPreOrderHelper(temp->getRightPtr(),visit);
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitInOrderHelper(Bnode<ItemType>* temp, void visit(ItemType))const{
	visitInOrderHelper(temp->getLeftPtr(),visit);
	visit;
	visitInOrderHelper(temp->getRightPtr(),visit);
}

template <typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::visitPostOrderHelper(Bnode<ItemType>* temp, void visit(ItemType))const{
	visitPostOrderHelper(temp->getLeftPtr(),visit);
	visitPostOrderHelper(temp->getRightPtr(),visit);
	visit;
}
