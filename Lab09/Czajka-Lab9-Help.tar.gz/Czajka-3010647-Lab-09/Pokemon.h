#ifndef POKEMON_H
#define POKEMON_H
#include <string>
class Pokemon{
private:
  int m_PokedexNumber;
  std::string m_AmericanName;
  std::string m_JapaneseName;

public:
  Pokemon(int tempPokedex, std::string tempAmerican, std::string tempJapanese);
  void setPokedex(int temp);
  void setAmerican(std::string temp);
  void setJapanese(std::string temp);
  int getPokedex()const;
  std::string getAmerican()const;
  std::string getJapanese()const;
  bool operator==(const Pokemon& right)const;
  bool operator<(const Pokemon& right)const;
  bool operator>(const Pokemon& right)const;
  //overload ID ints
  bool operator==(int id)const;
  bool operator<(int id)const;
  bool operator>(int id)const;
};

#endif
