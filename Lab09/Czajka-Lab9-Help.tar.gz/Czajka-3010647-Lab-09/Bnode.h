#ifndef BNODE_H
#define BNODE_H
#include "Pokemon.h"
template<typename T>
class Bnode{
private:
  Bnode<T>* left;
  Bnode<T>* right;
  T m_entry;
public:
  Bnode(T value);
  void setLeftPtr(Bnode<T>* temp);
  void setRightPtr(Bnode<T>* temp);
  void setEntry(T entry);
  Bnode<T>* getLeftPtr()const;
  Bnode<T>* getRightPtr()const;
  T getEntry()const;
};

#include "Bnode.cpp"
#endif
