/**
Checklist
  1)  Overload Operators |||Done
  1.5) Figure out why getting error message about class name ||DONE
  2) Finish writing mehtods for BinarySearchTree
  3) Write methods for Executive
  2) Do commments
  Need to fix operator overload
  converting from a bnode pointer to a pokemon type in line 40 of bst.cpp
**/


#include "Executive.h"

int main(){

}
