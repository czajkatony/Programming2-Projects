#ifndef BINARY_SEARCH_TREE_H
#define BINARY_SEARCH_TREE_H
#include "Bnode.h"
#include "BinarySearchTreeInterface.h"
#include <stdexcept>
#include <iostream>
template <typename ItemType, typename KeyType>
class BinarySearchTree : public BinarySearchTreeInterface<ItemType, KeyType>{
private:
  Bnode<ItemType>* m_root;

  
public:
  BinarySearchTree();//XXX
  void add(ItemType entry); //XXthrows std::runtime_error if duplicate added
  
  ItemType search(KeyType key) const; //XXXthrows std::runtime_error if not in tree
  void clear(); //Empties the tree ??||||STILL NEED TO DO
  void remove(KeyType key); //throws std::runtime_error if not in tree
  
  //MIGHT NEED TO PUT THESE IN PRIVATE
  void addHelper(Bnode<ItemType>* newNode, Bnode<ItemType>* compare);//XXX
  Bnode<ItemType>* removeHelper(KeyType key, Bnode<ItemType>* temp);

  //For the following methods, each method will take a function as a parameter
  //These function then call the provided function on every entry in the tree in the appropriate order (i.e. pre, in, post)
  //The function you pass in will need to a static method
  
  void visitPreOrder(void visit(ItemType)) const; //Visits each node in pre order
  void visitInOrder(void visit(ItemType)) const; //Visits each node in in order
  void visitPostOrder(void visit(ItemType)) const;
  //helper
  void visitPreOrderHelper(Bnode<ItemType>* temp, void visit(ItemType)) const; //Visits each node in pre order
  void visitInOrderHelper(Bnode<ItemType>* temp, void visit(ItemType)) const; //Visits each node in in order
  void visitPostOrderHelper(Bnode<ItemType>* temp, void visit(ItemType)) const; //Visits each no
};
#include "BinarySearchTree.cpp"
#endif
