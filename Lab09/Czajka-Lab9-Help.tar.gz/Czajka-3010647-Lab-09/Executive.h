#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include <string>
#include <fstream>
#include "Pokemon.h"
#include "BinarySearchTree.h"
class Executive{
public:
  Executive(std::string FileName);
  BinarySearchTree<Pokemon, int>* Pokedex;
};
#endif
